import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { ROLE_LABELS } from '../../utils/permissions';
import { UserRole } from '../../types';
import {
  HardHat,
  LayoutDashboard,
  Building2,
  TrendingUp,
  Users,
  Coins,
  Package,
  ShoppingCart,
  Truck,
  Wallet,
  Briefcase,
  FileText,
  Bell,
  WifiOff,
  CreditCard,
  LogOut,
  ChevronDown,
  Menu,
  X,
  Shield,
  Layers,
  ChevronRight,
} from 'lucide-react';

interface AppLayoutProps {
  children: React.ReactNode;
}

interface NavItem {
  id: string;
  name: string;
  icon: React.ElementType;
  step: number;
  badge?: string;
}

const NAVIGATION_ITEMS: NavItem[] = [
  { id: 'dashboard', name: 'Tableau de bord', icon: LayoutDashboard, step: 5 },
  { id: 'projects', name: 'Chantiers', icon: Building2, step: 6 },
  { id: 'progress', name: 'Suivi avancement', icon: TrendingUp, step: 7 },
  { id: 'attendance', name: 'Personnel & Pointage', icon: Users, step: 8 },
  { id: 'payroll', name: 'Paie & Salaires', icon: Coins, step: 9 },
  { id: 'stock', name: 'Stocks de matériaux', icon: Package, step: 10 },
  { id: 'orders', name: 'Bons de commande', icon: ShoppingCart, step: 11 },
  { id: 'deliveries', name: 'Bons de livraison', icon: Truck, step: 12 },
  { id: 'expenses', name: 'Dépenses & Budgets', icon: Wallet, step: 13 },
  { id: 'suppliers', name: 'Fournisseurs', icon: Briefcase, step: 14 },
  { id: 'reports', name: 'Rapports & Documents', icon: FileText, step: 15 },
  { id: 'notifications', name: 'Notifications', icon: Bell, step: 16 },
  { id: 'pwa', name: 'Mode Hors-ligne / PWA', icon: WifiOff, step: 17 },
  { id: 'subscriptions', name: 'Abonnements SaaS', icon: CreditCard, step: 18 },
];

export const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const { user, company, logout, switchDemoRole } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  if (!user || !company) return null;

  const roleMeta = ROLE_LABELS[user.role];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-slate-900/95 border-b border-slate-800 backdrop-blur-md px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-orange-600 flex items-center justify-center text-white font-black shadow-md shadow-orange-600/30">
              <HardHat className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold tracking-tight text-white text-base">BATI-PILOT</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-orange-500/10 text-orange-400 font-mono border border-orange-500/20">
                  v1.0 Étape 1
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">
                SaaS BTP Cameroun & Afrique Centrale
              </p>
            </div>
          </div>
        </div>

        {/* Info Entreprise & Sélecteur Rôle & Profil */}
        <div className="flex items-center gap-3">
          {/* Entreprise courante */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
            <Building2 className="w-3.5 h-3.5 text-orange-400" />
            <div className="leading-tight">
              <span className="font-semibold text-slate-200 block truncate max-w-[180px]">
                {company.name}
              </span>
              <span className="text-[10px] text-slate-400">{company.city} · {company.currency}</span>
            </div>
          </div>

          {/* Rôle actif et menu déroulant pour tester */}
          <div className="relative">
            <button
              onClick={() => setRoleMenuOpen(!roleMenuOpen)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-xs cursor-pointer transition-colors"
            >
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${roleMeta.badgeColor}`}>
                {roleMeta.label}
              </span>
              <span className="hidden sm:inline text-slate-300 font-medium">
                {user.firstName} {user.lastName}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* Dropdown de changement de rôle pour test */}
            {roleMenuOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-2 z-50">
                <div className="px-3 py-2 border-b border-slate-800 text-[11px] text-slate-400">
                  <span className="font-semibold text-slate-200 block">Basculement de rôle démo</span>
                  Testez instantanément l'application sous un autre profil :
                </div>
                <div className="py-1 space-y-1">
                  {(['DIRECTOR', 'SITE_MANAGER', 'STOREKEEPER', 'ACCOUNTANT', 'WORKER', 'SUPER_ADMIN'] as UserRole[]).map((r) => (
                    <button
                      key={r}
                      onClick={() => {
                        switchDemoRole(r);
                        setRoleMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between transition-colors ${
                        user.role === r
                          ? 'bg-orange-600/20 text-orange-300 font-semibold'
                          : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span>{ROLE_LABELS[r].label}</span>
                      {user.role === r && <span className="text-[10px] text-orange-400 font-bold">Actif</span>}
                    </button>
                  ))}
                </div>
                <div className="pt-2 border-t border-slate-800">
                  <button
                    onClick={() => {
                      setRoleMenuOpen(false);
                      logout();
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-red-400 hover:bg-red-950/40 flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Se déconnecter</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Déconnexion rapide */}
          <button
            onClick={logout}
            title="Déconnexion"
            className="p-2 rounded-lg bg-slate-800/60 hover:bg-red-950/40 hover:text-red-400 text-slate-400 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Body avec Sidebar et Contenu Principal */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar latérale */}
        <aside
          className={`fixed inset-y-0 left-0 z-30 w-64 bg-slate-900 border-r border-slate-800 transform transition-transform duration-200 ease-in-out lg:static lg:translate-x-0 flex flex-col justify-between pt-16 lg:pt-0 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="p-4 space-y-4 overflow-y-auto flex-1">
            {/* Statut Étape 1 */}
            <div className="p-3 rounded-xl bg-orange-950/30 border border-orange-500/30 text-xs space-y-1.5">
              <div className="flex items-center gap-2 text-orange-400 font-bold">
                <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping"></span>
                <span>Étape 1 en cours de test</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Validez ce premier module (Architecture & Auth) pour débloquer les 17 étapes suivantes pas à pas.
              </p>
            </div>

            {/* Menu des 14 modules du SaaS */}
            <nav className="space-y-1">
              <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                Modules Métier BTP (14)
              </p>

              {NAVIGATION_ITEMS.map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.id}
                    className="flex items-center justify-between px-3 py-2 rounded-lg text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon className="w-4 h-4 shrink-0 text-slate-400" />
                      <span className="truncate">{item.name}</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                      Étape {item.step}
                    </span>
                  </div>
                );
              })}
            </nav>
          </div>

          {/* Footer Sidebar */}
          <div className="p-4 border-t border-slate-800/80 bg-slate-950/50 text-[11px] text-slate-400 space-y-1">
            <p className="font-semibold text-slate-300">BATI-PILOT BTP</p>
            <p>Devise : XAF (FCFA)</p>
            <p>Douala · Yaoundé · Afrique</p>
          </div>
        </aside>

        {/* Zone de contenu principale */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
};
