/**
 * BATI-PILOT — Types et Modèles de Données
 * SaaS BTP pour l'Afrique francophone (Cameroun, devise XAF, fuseau Africa/Douala)
 */

export type UserRole =
  | 'SUPER_ADMIN'
  | 'DIRECTOR'
  | 'SITE_MANAGER'
  | 'STOREKEEPER'
  | 'ACCOUNTANT'
  | 'WORKER';

export type SubscriptionPlan = 'STARTER' | 'PRO' | 'ENTERPRISE';

export interface Company {
  id: string;
  name: string;
  slug: string;
  legalNumber?: string; // N° RC / Contribuable
  address: string;
  city: string; // Ex: Douala, Yaoundé, Bafoussam, Garoua
  country: string; // Cameroun
  currency: string; // XAF (FCFA)
  timezone: string; // Africa/Douala
  phone: string;
  email: string;
  logoUrl?: string;
  plan: SubscriptionPlan;
  maxProjects: number;
  maxUsers: number;
  status: 'ACTIVE' | 'TRIAL' | 'SUSPENDED';
  trialEndsAt?: string;
  createdAt: string;
}

export interface User {
  id: string;
  companyId: string;
  companyName?: string;
  role: UserRole;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  specialty?: string; // Ex: Ingénieur Génie Civil, Conducteur de travaux, Chef maçon
  avatarUrl?: string;
  assignedProjectIds: string[]; // Chantiers assignés
  isActive: boolean;
  createdAt: string;
}

export interface RolePermission {
  canViewAllProjects: boolean;
  canCreateProjects: boolean;
  canEditProjects: boolean;
  canViewBudgets: boolean;
  canEditBudgets: boolean;
  canRecordDailyProgress: boolean;
  canRecordAttendance: boolean;
  canValidateAttendance: boolean;
  canManagePayroll: boolean;
  canManageStock: boolean;
  canCreatePurchaseOrder: boolean;
  canApprovePurchaseOrder: boolean;
  canRecordDelivery: boolean;
  canRecordExpense: boolean;
  canViewReports: boolean;
  canManageUsers: boolean;
  canManageCompanySubscription: boolean;
  canManagePlatform: boolean; // Super Admin only
}

export interface Project {
  id: string;
  companyId: string;
  code: string; // Ex: CH-2026-DLA-01
  name: string;
  clientName: string;
  clientPhone?: string;
  location: string;
  city: string;
  lat?: number;
  lng?: number;
  description: string;
  startDate: string;
  expectedEndDate: string;
  budgetTotal: number; // en FCFA
  budgetSpent: number; // en FCFA
  managerId: string; // Chef de chantier référent
  managerName?: string;
  status: 'PREPARATION' | 'IN_PROGRESS' | 'SUSPENDED' | 'COMPLETED' | 'CANCELLED';
  progressPercentage: number;
  workersCount: number;
  createdAt: string;
}

export interface AuthResponse {
  token: string;
  user: User;
  company: Company;
}

export interface ApiStepLog {
  step: number;
  name: string;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING';
  description: string;
}
