/**
 * BATI-PILOT — Magasin de données backend (in-memory avec persistence multi-entreprises)
 * Pré-configuré avec des données réalistes BTP Cameroun (Douala / Yaoundé)
 */

import { Company, User, Project } from '../src/types';

export interface DatabaseState {
  companies: Company[];
  users: (User & { passwordHash: string })[];
  projects: Project[];
}

export const initialCompanies: Company[] = [
  {
    id: 'comp_socabat_01',
    name: 'SOCABAT SARL (Bâtiment & Travaux Publics)',
    slug: 'socabat',
    legalNumber: 'RC/DLA/2018/B/421 - NIU: M051812739482X',
    address: 'Boulevard de la Liberté, Bonanjo',
    city: 'Douala',
    country: 'Cameroun',
    currency: 'XAF',
    timezone: 'Africa/Douala',
    phone: '+237 699 45 12 80',
    email: 'contact@socabat.cm',
    plan: 'PRO',
    maxProjects: 10,
    maxUsers: 20,
    status: 'ACTIVE',
    createdAt: '2026-01-10T08:00:00Z',
  },
  {
    id: 'comp_sahel_02',
    name: 'SAHEL INFRASTRUCTURES & GÉNIE CIVIL',
    slug: 'sahel-infra',
    legalNumber: 'RC/YAO/2020/B/890 - NIU: M032014859601Y',
    address: 'Avenue Rosa Parks, Bastos',
    city: 'Yaoundé',
    country: 'Cameroun',
    currency: 'XAF',
    timezone: 'Africa/Douala',
    phone: '+237 677 30 19 44',
    email: 'direction@sahel-infra.cm',
    plan: 'STARTER',
    maxProjects: 2,
    maxUsers: 5,
    status: 'TRIAL',
    trialEndsAt: '2026-11-20T23:59:59Z',
    createdAt: '2026-10-15T10:00:00Z',
  },
];

export const initialProjects: Project[] = [
  {
    id: 'proj_akwa_01',
    companyId: 'comp_socabat_01',
    code: 'CH-2026-DLA-01',
    name: 'Immeuble R+5 Commercial & Bureaux Akwa',
    clientName: 'SCI Le Phénix Douala',
    clientPhone: '+237 699 80 12 34',
    location: 'Rue Pau, Quartier Akwa',
    city: 'Douala',
    lat: 4.0511,
    lng: 9.7085,
    description: 'Construction gros œuvre, maçonnerie, électricité et second œuvre complet.',
    startDate: '2026-02-01',
    expectedEndDate: '2026-12-15',
    budgetTotal: 185000000, // 185 millions FCFA
    budgetSpent: 74200000,  // 74.2 millions FCFA
    managerId: 'usr_chef_01',
    managerName: 'Ing. Paul Ndongo',
    status: 'IN_PROGRESS',
    progressPercentage: 42,
    workersCount: 28,
    createdAt: '2026-01-20T09:00:00Z',
  },
  {
    id: 'proj_laquintinie_02',
    companyId: 'comp_socabat_01',
    code: 'CH-2026-DLA-02',
    name: 'Réhabilitation Pavillon Mère & Enfant Hôpital Laquintinie',
    clientName: 'Délégation Régionale de la Santé Littoral',
    clientPhone: '+237 670 11 22 33',
    location: 'Hôpital Laquintinie, Akwa Nord',
    city: 'Douala',
    lat: 4.0583,
    lng: 9.7042,
    description: 'Renforcement structurel, plomberie sanitaire médicale et carrelage.',
    startDate: '2026-03-10',
    expectedEndDate: '2026-08-30',
    budgetTotal: 65000000, // 65 millions FCFA
    budgetSpent: 38400000,
    managerId: 'usr_chef_01',
    managerName: 'Ing. Paul Ndongo',
    status: 'IN_PROGRESS',
    progressPercentage: 68,
    workersCount: 16,
    createdAt: '2026-03-01T11:00:00Z',
  },
  {
    id: 'proj_bastos_03',
    companyId: 'comp_sahel_02',
    code: 'CH-2026-YDE-01',
    name: 'Voie Pavée Résidentielle et Caniveaux Bastos',
    clientName: 'Syndicat des Copropriétaires Bastos',
    clientPhone: '+237 691 55 44 22',
    location: 'Descente Ambassade, Bastos',
    city: 'Yaoundé',
    lat: 3.8922,
    lng: 11.5133,
    description: 'Terrassement, pose de bordures T2 et pavés autobloquants 8cm.',
    startDate: '2026-05-01',
    expectedEndDate: '2026-10-31',
    budgetTotal: 42000000,
    budgetSpent: 12500000,
    managerId: 'usr_chef_sahel',
    managerName: 'Ing. Moussa Bello',
    status: 'IN_PROGRESS',
    progressPercentage: 30,
    workersCount: 12,
    createdAt: '2026-04-20T14:00:00Z',
  },
];

export const initialUsers: (User & { passwordHash: string })[] = [
  {
    id: 'usr_superadmin',
    companyId: 'comp_socabat_01',
    companyName: 'BATI-PILOT Platform',
    role: 'SUPER_ADMIN',
    email: 'superadmin@batipilot.cm',
    passwordHash: 'bati2026',
    firstName: 'Alain',
    lastName: 'Mbassi',
    phone: '+237 699 00 11 22',
    specialty: 'Directeur Plateforme SaaS',
    assignedProjectIds: [],
    isActive: true,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'usr_directeur_01',
    companyId: 'comp_socabat_01',
    companyName: 'SOCABAT SARL',
    role: 'DIRECTOR',
    email: 'directeur@socabat.cm',
    passwordHash: 'bati2026',
    firstName: 'Samuel',
    lastName: "Eto'o Mbarga",
    phone: '+237 699 45 12 80',
    specialty: 'Directeur Général & Promoteur BTP',
    assignedProjectIds: ['proj_akwa_01', 'proj_laquintinie_02'],
    isActive: true,
    createdAt: '2026-01-10T08:00:00Z',
  },
  {
    id: 'usr_chef_01',
    companyId: 'comp_socabat_01',
    companyName: 'SOCABAT SARL',
    role: 'SITE_MANAGER',
    email: 'chef.chantier@socabat.cm',
    passwordHash: 'bati2026',
    firstName: 'Paul',
    lastName: 'Ndongo',
    phone: '+237 677 88 99 00',
    specialty: 'Conducteur de Travaux / Génie Civil',
    assignedProjectIds: ['proj_akwa_01', 'proj_laquintinie_02'],
    isActive: true,
    createdAt: '2026-01-12T09:00:00Z',
  },
  {
    id: 'usr_magasinier_01',
    companyId: 'comp_socabat_01',
    companyName: 'SOCABAT SARL',
    role: 'STOREKEEPER',
    email: 'magasinier@socabat.cm',
    passwordHash: 'bati2026',
    firstName: 'Christian',
    lastName: 'Talla',
    phone: '+237 655 44 33 22',
    specialty: 'Gestionnaire Dépôt & Stocks BTP',
    assignedProjectIds: ['proj_akwa_01', 'proj_laquintinie_02'],
    isActive: true,
    createdAt: '2026-01-15T10:00:00Z',
  },
  {
    id: 'usr_comptable_01',
    companyId: 'comp_socabat_01',
    companyName: 'SOCABAT SARL',
    role: 'ACCOUNTANT',
    email: 'comptable@socabat.cm',
    passwordHash: 'bati2026',
    firstName: 'Nadine',
    lastName: 'Ngo Bell',
    phone: '+237 691 22 33 44',
    specialty: 'Responsable Financière & Paie',
    assignedProjectIds: ['proj_akwa_01', 'proj_laquintinie_02'],
    isActive: true,
    createdAt: '2026-01-15T11:00:00Z',
  },
  {
    id: 'usr_ouvrier_01',
    companyId: 'comp_socabat_01',
    companyName: 'SOCABAT SARL',
    role: 'WORKER',
    email: 'ouvrier@socabat.cm',
    passwordHash: 'bati2026',
    firstName: 'Joseph',
    lastName: 'Kamga',
    phone: '+237 673 12 34 56',
    specialty: 'Chef Maçon & Coffreur',
    assignedProjectIds: ['proj_akwa_01'],
    isActive: true,
    createdAt: '2026-02-01T07:00:00Z',
  },
];

// Singleton Database Manager
class DatabaseManager {
  private state: DatabaseState;

  constructor() {
    this.state = {
      companies: [...initialCompanies],
      users: [...initialUsers],
      projects: [...initialProjects],
    };
  }

  getCompanies(): Company[] {
    return this.state.companies;
  }

  getCompanyById(id: string): Company | undefined {
    return this.state.companies.find((c) => c.id === id);
  }

  createCompany(data: Omit<Company, 'id' | 'createdAt'>): Company {
    const newCompany: Company = {
      ...data,
      id: `comp_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.state.companies.push(newCompany);
    return newCompany;
  }

  getUsers(companyId?: string): User[] {
    const users = this.state.users.map(({ passwordHash, ...rest }) => rest);
    if (!companyId) return users;
    return users.filter((u) => u.companyId === companyId);
  }

  getUserByEmail(email: string) {
    return this.state.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  getUserById(id: string) {
    return this.state.users.find((u) => u.id === id);
  }

  createUser(data: Omit<User, 'id' | 'createdAt'> & { passwordHash: string }) {
    const newUser = {
      ...data,
      id: `usr_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.state.users.push(newUser);
    const { passwordHash, ...safeUser } = newUser;
    return safeUser;
  }

  getProjects(companyId: string): Project[] {
    return this.state.projects.filter((p) => p.companyId === companyId);
  }
}

export const db = new DatabaseManager();
