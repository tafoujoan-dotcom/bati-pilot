import { Router, Request, Response } from 'express';
import { db } from './db.js';
import { UserRole, SubscriptionPlan } from '../src/types';

export const apiRouter = Router();

// Middleware de vérification de session simple / Bearer token
function parseAuthToken(req: Request) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const parts = authHeader.split(' ');
  if (parts.length === 2 && parts[0] === 'Bearer') {
    return parts[1];
  }
  return null;
}

/**
 * GET /api/system/health
 * Statut général du système SaaS
 */
apiRouter.get('/system/health', (req: Request, res: Response) => {
  res.json({
    status: 'online',
    app: 'BATI-PILOT',
    version: '1.0.0-step1',
    environment: 'production-ready',
    currency: 'XAF',
    timezone: 'Africa/Douala',
    activeStep: 1,
    stepTitle: 'Architecture générale, initialisation et authentification multi-rôles',
    stats: {
      companiesCount: db.getCompanies().length,
      usersCount: db.getUsers().length,
    },
  });
});

/**
 * GET /api/auth/demo-accounts
 * Liste des 6 comptes démo préconfigurés pour tester chaque rôle BTP
 */
apiRouter.get('/auth/demo-accounts', (req: Request, res: Response) => {
  const users = db.getUsers('comp_socabat_01');
  const superAdmin = db.getUsers().find((u) => u.role === 'SUPER_ADMIN');

  const demoAccounts = [
    {
      role: 'SUPER_ADMIN' as UserRole,
      title: 'Super Administrateur',
      name: 'Alain Mbassi',
      email: 'superadmin@batipilot.cm',
      password: 'bati2026',
      badge: 'Plateforme SaaS',
      description: 'Supervision globale de tous les tenants et abonnements',
    },
    {
      role: 'DIRECTOR' as UserRole,
      title: "Directeur Général (DG)",
      name: "Samuel Eto'o Mbarga",
      email: 'directeur@socabat.cm',
      password: 'bati2026',
      badge: 'SOCABAT SARL',
      description: 'Accès décisionnaire à tous les chantiers, finances et RH',
    },
    {
      role: 'SITE_MANAGER' as UserRole,
      title: 'Conducteur / Chef de Chantier',
      name: 'Ing. Paul Ndongo',
      email: 'chef.chantier@socabat.cm',
      password: 'bati2026',
      badge: 'Chantiers Akwa & Laquintinie',
      description: 'Saisie quotidienne, pointage, besoins matériels et incidents',
    },
    {
      role: 'STOREKEEPER' as UserRole,
      title: 'Magasinier Dépôt Central',
      name: 'Christian Talla',
      email: 'magasinier@socabat.cm',
      password: 'bati2026',
      badge: 'Dépôt Central Bassa',
      description: 'Gestion des stocks, entrées/sorties et réceptions',
    },
    {
      role: 'ACCOUNTANT' as UserRole,
      title: 'Comptable & Paie',
      name: 'Nadine Ngo Bell',
      email: 'comptable@socabat.cm',
      password: 'bati2026',
      badge: 'Direction Financière',
      description: 'Suivi des dépenses, paiements des journaliers et factures',
    },
    {
      role: 'WORKER' as UserRole,
      title: 'Ouvrier / Chef Maçon',
      name: 'Joseph Kamga',
      email: 'ouvrier@socabat.cm',
      password: 'bati2026',
      badge: 'Équipe Akwa',
      description: 'Consultation de ses pointages et fiches de paiement',
    },
  ];

  res.json({ demoAccounts });
});

/**
 * POST /api/auth/login
 * Authentification avec email et mot de passe
 */
apiRouter.post('/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Veuillez saisir votre adresse email et votre mot de passe.' });
  }

  const userWithPassword = db.getUserByEmail(email);
  if (!userWithPassword) {
    return res.status(401).json({ error: 'Identifiants incorrects. Aucun compte trouvé avec cet email.' });
  }

  if (userWithPassword.passwordHash !== password) {
    return res.status(401).json({ error: 'Mot de passe incorrect. Veuillez vérifier votre saisie.' });
  }

  if (!userWithPassword.isActive) {
    return res.status(403).json({ error: 'Ce compte utilisateur a été désactivé par l’administrateur.' });
  }

  const company = db.getCompanyById(userWithPassword.companyId);
  if (!company) {
    return res.status(500).json({ error: 'Entreprise associée introuvable.' });
  }

  // Simulation d'un token sécurisé
  const token = `btp_tk_${userWithPassword.id}_${Date.now()}`;
  const { passwordHash, ...safeUser } = userWithPassword;

  return res.json({
    token,
    user: { ...safeUser, companyName: company.name },
    company,
  });
});

/**
 * POST /api/auth/register-company
 * Création d'une nouvelle entreprise cliente avec son compte Directeur
 */
apiRouter.post('/auth/register-company', (req: Request, res: Response) => {
  const {
    companyName,
    city,
    phone,
    email,
    firstName,
    lastName,
    password,
    plan = 'PRO',
  } = req.body;

  if (!companyName || !email || !password || !firstName || !lastName) {
    return res.status(400).json({ error: 'Tous les champs obligatoires doivent être renseignés.' });
  }

  const existingUser = db.getUserByEmail(email);
  if (existingUser) {
    return res.status(409).json({ error: 'Cette adresse email est déjà utilisée par une entreprise.' });
  }

  const planSelected = (plan as SubscriptionPlan) || 'PRO';
  const maxProjects = planSelected === 'STARTER' ? 2 : planSelected === 'PRO' ? 10 : 999;
  const maxUsers = planSelected === 'STARTER' ? 5 : planSelected === 'PRO' ? 20 : 999;

  // Création de l'entreprise
  const newCompany = db.createCompany({
    name: companyName,
    slug: companyName.toLowerCase().replace(/[^a-z0-9]/g, '-'),
    address: `Siège social, ${city || 'Douala'}`,
    city: city || 'Douala',
    country: 'Cameroun',
    currency: 'XAF',
    timezone: 'Africa/Douala',
    phone: phone || '+237 600 00 00 00',
    email,
    plan: planSelected,
    maxProjects,
    maxUsers,
    status: 'TRIAL',
    trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(), // 14 jours d'essai
  });

  // Création de l'utilisateur directeur
  const newUser = db.createUser({
    companyId: newCompany.id,
    role: 'DIRECTOR',
    email,
    passwordHash: password,
    firstName,
    lastName,
    phone: phone || '',
    specialty: 'Directeur Général',
    assignedProjectIds: [],
    isActive: true,
  });

  const token = `btp_tk_${newUser.id}_${Date.now()}`;

  return res.status(201).json({
    token,
    user: { ...newUser, companyName: newCompany.name },
    company: newCompany,
    message: 'Votre entreprise et votre compte Directeur ont été créés avec succès !',
  });
});

/**
 * GET /api/auth/me
 * Vérification de la session en cours
 */
apiRouter.get('/auth/me', (req: Request, res: Response) => {
  const token = parseAuthToken(req);
  if (!token) {
    return res.status(401).json({ error: 'Non authentifié. Aucun jeton de session fourni.' });
  }

  // Décoder token simple btp_tk_usr_..._timestamp
  const match = token.match(/btp_tk_([a-zA-Z0-9_]+)_\d+/);
  if (!match) {
    return res.status(401).json({ error: 'Jeton de session invalide ou expiré.' });
  }

  const userId = match[1];
  const user = db.getUserById(userId);
  if (!user) {
    return res.status(401).json({ error: 'Session invalide. Utilisateur introuvable.' });
  }

  const company = db.getCompanyById(user.companyId);
  const { passwordHash, ...safeUser } = user;

  return res.json({
    user: { ...safeUser, companyName: company?.name },
    company,
  });
});

/**
 * GET /api/companies
 * Liste des entreprises enregistrées pour démonstration multi-tenant
 */
apiRouter.get('/companies', (req: Request, res: Response) => {
  const companies = db.getCompanies();
  res.json({ companies });
});
